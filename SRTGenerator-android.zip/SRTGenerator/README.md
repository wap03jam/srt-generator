# SRT Generator (Android)

Offline app. A WebView loads app/src/main/assets/index.html.

## Build the APK
1. Install Android Studio (latest). Unzip this folder.
2. File > Open > select the SRTGenerator folder. Let Gradle sync (first time needs internet; accept any SDK install prompts).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk.
5. Copy it to your phone and open it. Allow "install unknown apps" when asked.

To change the generator itself, edit app/src/main/assets/index.html.
